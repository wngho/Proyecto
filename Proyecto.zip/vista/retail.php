<!-- Landing page 
"esta es la pagina principal del proyecto, cuando se entra primera vez 
y cuando no haya sesion iniciada esta sera la primera vista a mostrar"
Info: solo es una vista de bienvenida, acceso a la login a traves de sus referencias
Estado: medio (falta añadir detalles para que este terminada) 
-->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda!</title>
    <?php require_once("common/linkcss.php"); ?>
</head>
<body>
    <header>
    <?php require_once("common/menu.php"); ?>
    </header>
    <!-- Sección de bienvenida -->
      <div class="container mt-5 ">

        <section class="row">
          <header>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#" class="fst-italic">Pc de Escritorio</a></li>
                <li class="breadcrumb-item"><a href="#" class="fst-italic">12 Gen</a></li>
                <li class="breadcrumb-item active fst-italic" aria-current="page" >Gamer</li>
              </ol>
            </nav>
          </header class="">
          <aside class="col-lg-5 mt-3">
            <img src="img/pcimg.png" alt="producto" class="img-fluid border border-2 rounded-4">
          </aside>
          <div class="col-1"></div>
          <article class="col-lg-6 mt-3">
            <div class="row">
              <div class="col">
                <div class="border-bottom border-secondary-subtle pb-4">
                  <span class="blockquotes text-secondary">
                    Pc de Escritorio
                  </span></br>
                  <span class="display-4 fw-medium">PC Gamer</span></br>
                  <span class="estrellas text-warning">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-half"></i>
                  </span>
                  <span class="blockquotes text-success">  (5 Reviews)</span>
                  <div class="precio mt-3">
                    <span class="display-6 fs-3 fw-bold">$ 380</span>
                    <span class="display-6 fs-3 fw-medium text-secondary text-decoration-line-through">$ 450</span>
                    <span class="display-6 fs-3 fw-bold">$ 380</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col ms-3 mt-3">
                <button class="btn btn-outline-dark me-2">Negro</button>
                <button class="btn btn-outline-dark">Blanco</button>    
              </div>              
            </div>
              <div class="row">
                <div class="col">
                  <div class="quantity-counter d-flex align-items-center input-group mt-3 ms-3">
                    <button class="quantity-btn btn btn-outline-danger border-secondary rounded-start" onclick="decrement()">-</button>
                    <input type="number" class="quantity-input form-control border-secondary" id="quantity" value="1" min="15">
                    <button class="quantity-btn btn btn-outline-success border-secondary rounded-end" onclick="increment()">+</button>
                  </div>
                </div>
              </div>
              <div class="row mt-3 border-bottom border-secondary-subtle pb-4">
                <div class="col">
                  <button class="btn btn-success ms-3 fs-5"><i class="bi bi-bag-dash-fill me-2"></i>Añadir al carrito</button>
                  <button class="btn btn-outline-danger fs-5"><i class="bi bi-heart"></i></button>
                </div>
              </div>
              <div class="row mt-3 text-secondary">
                <div class="row my-3 ">
                  <div class="col-4">
                    <span class="fw-bold">Codigo del Producto:</span>
                  </div>
                  <div class="col-6">
                    <span class="fw-medium">3F67S98A2DS</span>
                  </div>
                </div>
                <div class="row my-3">
                  <div class="col-4">
                    <span class="fw-bold">Disponibilidad:</span>
                  </div>
                  <div class="col-6">
                    <span class="fw-medium">Disponible</span>
                  </div>
                </div>
                
                <div class="row my-3">
                  <div class="col-4">
                    <span class="fw-bold">Dias para realizar el despacho:</span>
                  </div>
                  <div class="col-6">
                    <span class="fw-medium">3 Dias</span>
                  </div>
                </div>
                </div>
          </article>

        <section class="row mt-3 mb-3 ">
          <div class="row">
            <div class="col">
              <ul class="nav nav-tabs text-success">
                <li class="nav-item">
                  <a class="nav-link active" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="Descripcion" aria-current="page" href="#">Descripcion</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="Espec" aria-current="page" href="#">Especificaciones</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="Review" aria-current="page" href="#">Reviews</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="Seller" aria-current="page" href="#">Opiniones del vendedor</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <div class="collapse" id="Descripcion">
                <p>HOla</p>
              </div>
              <div class="collapse" id="Espec">
                <p>Hola como esta</p>
              </div>
            </div>
          </div>
        </section>

      </div>
    <footer>
    <?php require_once("common/footer.php"); ?>
    </footer>
    <script src="js/landing.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/categoria.js"></script>
    <script src="js/contador.js"></script>
    
</body>
</html>   