<?php 
$page = "home"; 
session_start();

  if (!empty($_GET['page']))
  {
    
    $page = $_GET['page'];
  // if (!isset($_SESSION['id_usuario']) && ($p != "principal" && $p != "login" && $p != "consulta" && $p != "detallesdeuda")) {
   //  header("Location: ?p=login");
   //}
  }
  if(is_file("controlador/".$page.".php")){ 
    
    require_once("controlador/".$page.".php");
  }
  else
  {
    
    require_once("controlador/404.php"); 
  }
?> 