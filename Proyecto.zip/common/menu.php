<nav class="navbar navbar-expand-lg bg-info" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Gimnasio Wong Suarez UPTAEB</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        
      </ul>
      <ul class="navbar-nav">
      <li class="nav-item">
          <a class="nav-link active" href="#">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Modulo</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Modulo</a>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Modulo</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Accion</a>
            <a class="dropdown-item" href="#">Accion</a>
            <a class="dropdown-item" href="#">Accion</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Accion separada</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?page=login">Iniciar sesion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?page=tienda">Tienda</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">Salir</a>
        </li>
      </ul>
    </div>
  </div>
</nav>