<div class="container text-center" >
    <div class="row">
      <div class="col">
        <h5>Contacto</h5>
        <ul class="list-unstyled">
          <li><a href="mailto:info@ejemplo.com">jugneycontacto@gmail.com</a></li>
          <li><a href="tel:+58 123465">+58 1234586</a></li>
        </ul>
      </div>
      <div class="col">
        <h5>Ayuda</h5>
        <ul class="list-unstyled">
          <li><a href="#!">Preguntas Frecuentes</a></li>
          <li><a href="#!">Soporte</a></li>
        </ul>
      </div>
      <div class="col">
        <h5>Más</h5>
        <ul class="list-unstyled">
          <li><a href="#!">Términos de Uso</a></li>
          <li><a href="#!">Privacidad</a></li>
        </ul>
      </div>
    </div>
  </div>